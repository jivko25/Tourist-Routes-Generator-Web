import { useEffect, useState } from 'react'

// ─── Font injection ────────────────────────────────────────────────────────────
function useFonts() {
  useEffect(() => {
    if (document.getElementById('travelgo-fonts')) return
    const link = document.createElement('link')
    link.id = 'travelgo-fonts'
    link.rel = 'stylesheet'
    link.href =
      'https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap'
    document.head.appendChild(link)
  }, [])
}

// ─── Design tokens ─────────────────────────────────────────────────────────────
const C = {
  primary: '#3B82F6',
  primarySoft: '#E8F3FF',
  primaryDark: '#2563EB',
  accent: '#F97316',
  accentSoft: '#FFF1E6',
  bg: '#F7FBFF',
  surface: '#FFFFFF',
  surfaceMuted: '#EEF5FF',
  text: '#0F172A',
  muted: '#64748B',
  border: 'rgba(59, 130, 246, 0.16)',
  success: '#16A34A',
} as const

const display = "'Plus Jakarta Sans', sans-serif"
const body = "'DM Sans', sans-serif"

// ─── SVG icons ─────────────────────────────────────────────────────────────────
function MapPinIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"
        fill={color}
        opacity={0.9}
      />
      <circle cx="12" cy="9" r="2.5" fill="white" />
    </svg>
  )
}

function RouteIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="6" cy="6" r="2.5" fill={color} />
      <circle cx="18" cy="18" r="2.5" fill={color} />
      <path d="M6 8.5v3a4 4 0 004 4h.5" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <path d="M14.5 15.5h1a2.5 2.5 0 000-5H9.5a2.5 2.5 0 010-5H11" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  )
}

function ClockIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="9" stroke={color} strokeWidth="1.8" />
      <path d="M12 7v5l3 3" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function DownloadCloudIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M8 17H5.5A4.5 4.5 0 015.5 8a.5.5 0 00.5-.5A6 6 0 0118 9h.5a3.5 3.5 0 010 7H16" stroke={color} strokeWidth="1.8" strokeLinecap="round" />
      <path d="M12 12v7M9.5 16.5L12 19l2.5-2.5" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function SparklesIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z" fill={color} opacity={0.9} />
      <path d="M19 3l.8 2.2L22 6l-2.2.8L19 9l-.8-2.2L16 6l2.2-.8L19 3z" fill={color} opacity={0.6} />
      <path d="M5 17l.6 1.4L7 19l-1.4.6L5 21l-.6-1.4L3 19l1.4-.6L5 17z" fill={color} opacity={0.6} />
    </svg>
  )
}

function BookmarkIcon({ size = 20, color = C.primary }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M5 3h14a1 1 0 011 1v17l-8-4-8 4V4a1 1 0 011-1z" stroke={color} strokeWidth="1.8" strokeLinejoin="round" fill={color} fillOpacity={0.15} />
    </svg>
  )
}

function PhoneIcon({ size = 20, color = 'white' }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="5" y="2" width="14" height="20" rx="3" stroke={color} strokeWidth="1.8" />
      <circle cx="12" cy="18.5" r="1" fill={color} />
    </svg>
  )
}

function ChevronRightIcon({ size = 16, color = C.primaryDark }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M9 18l6-6-6-6" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

// ─── Buttons ───────────────────────────────────────────────────────────────────
function PrimaryButton({
  children,
  size = 'md',
  onClick,
}: {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  onClick?: () => void
}) {
  const pad = size === 'lg' ? '14px 32px' : size === 'sm' ? '8px 18px' : '11px 24px'
  const fs = size === 'lg' ? 17 : size === 'sm' ? 13 : 15
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: pad,
        backgroundColor: C.accent,
        color: 'white',
        borderRadius: 999,
        border: 'none',
        cursor: 'pointer',
        fontFamily: display,
        fontWeight: 700,
        fontSize: fs,
        letterSpacing: '-0.01em',
        transition: 'opacity 0.15s, transform 0.1s',
        boxShadow: '0 2px 12px rgba(249,115,22,0.28)',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.92' }}
      onMouseLeave={(e) => { e.currentTarget.style.opacity = '1' }}
      onMouseDown={(e) => { e.currentTarget.style.transform = 'scale(0.97)' }}
      onMouseUp={(e) => { e.currentTarget.style.transform = 'scale(1)' }}
    >
      {children}
    </button>
  )
}

function SecondaryButton({
  children,
  size = 'md',
  onClick,
}: {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  onClick?: () => void
}) {
  const pad = size === 'lg' ? '13px 31px' : size === 'sm' ? '7px 17px' : '10px 23px'
  const fs = size === 'lg' ? 17 : size === 'sm' ? 13 : 15
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: pad,
        backgroundColor: 'rgba(255,255,255,0.18)',
        color: 'white',
        borderRadius: 999,
        border: '1.5px solid rgba(255,255,255,0.45)',
        cursor: 'pointer',
        fontFamily: display,
        fontWeight: 600,
        fontSize: fs,
        letterSpacing: '-0.01em',
        backdropFilter: 'blur(8px)',
        transition: 'opacity 0.15s, transform 0.1s',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.26)' }}
      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.18)' }}
      onMouseDown={(e) => { e.currentTarget.style.transform = 'scale(0.97)' }}
      onMouseUp={(e) => { e.currentTarget.style.transform = 'scale(1)' }}
    >
      {children}
    </button>
  )
}

function OutlineButton({
  children,
  size = 'md',
  onClick,
}: {
  children: React.ReactNode
  size?: 'sm' | 'md' | 'lg'
  onClick?: () => void
}) {
  const pad = size === 'lg' ? '13px 31px' : size === 'sm' ? '7px 17px' : '10px 23px'
  const fs = size === 'lg' ? 17 : size === 'sm' ? 13 : 15
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
        padding: pad,
        backgroundColor: C.primarySoft,
        color: C.primaryDark,
        borderRadius: 999,
        border: `1.5px solid ${C.border}`,
        cursor: 'pointer',
        fontFamily: display,
        fontWeight: 600,
        fontSize: fs,
        letterSpacing: '-0.01em',
        transition: 'opacity 0.15s, transform 0.1s',
      }}
      onMouseEnter={(e) => { e.currentTarget.style.backgroundColor = '#daeaff' }}
      onMouseLeave={(e) => { e.currentTarget.style.backgroundColor = C.primarySoft }}
      onMouseDown={(e) => { e.currentTarget.style.transform = 'scale(0.97)' }}
      onMouseUp={(e) => { e.currentTarget.style.transform = 'scale(1)' }}
    >
      {children}
    </button>
  )
}

// ─── Store badges ──────────────────────────────────────────────────────────────
function StoreBadgeRow({ stacked = false }: { stacked?: boolean }) {
  const badgeStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 10,
    padding: '10px 18px',
    backgroundColor: C.text,
    color: 'white',
    borderRadius: 12,
    cursor: 'pointer',
    transition: 'opacity 0.15s',
    textDecoration: 'none',
    fontFamily: body,
    minWidth: 148,
  }
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: stacked ? 'column' : 'row',
        gap: 10,
        alignItems: stacked ? 'flex-start' : 'center',
        flexWrap: 'wrap',
      }}
    >
      <a
        href="#"
        style={badgeStyle}
        onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.85' }}
        onMouseLeave={(e) => { e.currentTarget.style.opacity = '1' }}
        aria-label="Get on Google Play"
      >
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
          <path d="M4 3.5L13.5 12 4 20.5" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 3.5L19 12 13.5 12" stroke="#2196F3" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 20.5L19 12 13.5 12" stroke="#F44336" strokeWidth="2" strokeLinecap="round" />
          <path d="M4 3.5L4 20.5" stroke="#FFB300" strokeWidth="2" strokeLinecap="round" />
        </svg>
        <div>
          <div style={{ fontSize: 9, opacity: 0.75, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Get it on</div>
          <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: '-0.02em', fontFamily: display }}>Google Play</div>
        </div>
      </a>
      <a
        href="#"
        style={{ ...badgeStyle, backgroundColor: '#1a1a2e' }}
        onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.85' }}
        onMouseLeave={(e) => { e.currentTarget.style.opacity = '1' }}
        aria-label="Download on App Store"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="white" aria-hidden>
          <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
        </svg>
        <div>
          <div style={{ fontSize: 9, opacity: 0.75, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Download on the</div>
          <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: '-0.02em', fontFamily: display }}>App Store</div>
        </div>
      </a>
    </div>
  )
}

// ─── QR code SVG ───────────────────────────────────────────────────────────────
const QR_MATRIX = [
  [1,1,1,1,1,1,1,0,1,1,0,1,0,0,1,1,1,1,1,1,1],
  [1,0,0,0,0,0,1,0,0,1,1,0,1,0,1,0,0,0,0,0,1],
  [1,0,1,1,1,0,1,0,1,0,1,1,0,0,1,0,1,1,1,0,1],
  [1,0,1,1,1,0,1,0,0,1,0,0,1,0,1,0,1,1,1,0,1],
  [1,0,1,1,1,0,1,0,1,1,1,0,0,0,1,0,1,1,1,0,1],
  [1,0,0,0,0,0,1,0,0,0,1,1,0,0,1,0,0,0,0,0,1],
  [1,1,1,1,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1],
  [0,0,0,0,0,0,0,0,1,1,0,1,1,0,0,0,0,0,0,0,0],
  [1,0,1,1,0,1,1,1,0,1,0,0,1,1,1,0,1,0,0,1,1],
  [0,1,0,0,1,0,0,0,1,0,1,1,0,0,0,1,0,1,1,0,0],
  [1,1,0,1,0,0,1,0,1,0,0,1,1,0,1,1,0,0,1,1,0],
  [0,0,1,0,1,1,0,1,0,1,1,0,0,1,0,0,1,1,0,0,1],
  [1,0,0,1,0,0,1,1,1,0,1,1,0,1,1,0,0,1,0,1,0],
  [0,0,0,0,0,0,0,0,1,1,0,0,1,0,0,1,1,0,1,0,1],
  [1,1,1,1,1,1,1,0,0,0,1,0,0,1,0,0,1,1,0,1,0],
  [1,0,0,0,0,0,1,0,1,1,0,1,1,0,1,0,0,0,1,0,1],
  [1,0,1,1,1,0,1,0,0,1,1,0,0,1,0,1,1,0,0,0,0],
  [1,0,1,1,1,0,1,0,1,0,0,1,0,0,1,1,0,1,0,1,1],
  [1,0,1,1,1,0,1,0,0,1,1,0,1,0,0,0,1,0,1,0,0],
  [1,0,0,0,0,0,1,0,1,0,0,1,0,1,1,0,0,1,0,1,0],
  [1,1,1,1,1,1,1,0,0,1,1,0,1,0,0,1,0,0,1,0,1],
]

function QRCodeSVG({ size = 200 }: { size?: number }) {
  const N = 21
  const quiet = 3
  const total = N + quiet * 2
  const cell = size / total
  const off = quiet * cell

  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="QR code to download Travel Go"
    >
      <rect width={size} height={size} fill="white" />
      {QR_MATRIX.map((row, r) =>
        row.map((bit, c) =>
          bit ? (
            <rect
              key={`${r}-${c}`}
              x={off + c * cell}
              y={off + r * cell}
              width={cell}
              height={cell}
              fill={C.text}
            />
          ) : null,
        ),
      )}
      {/* Center logo mark */}
      <rect
        x={size / 2 - 18}
        y={size / 2 - 10}
        width={36}
        height={20}
        rx={4}
        fill="white"
      />
      <text
        x={size / 2}
        y={size / 2 + 5}
        textAnchor="middle"
        fill={C.primary}
        fontSize={10}
        fontWeight="800"
        fontFamily={display}
      >
        TG
      </text>
    </svg>
  )
}

// ─── QR download card ──────────────────────────────────────────────────────────
function QrDownloadCard({ compact = false }: { compact?: boolean }) {
  return (
    <div
      style={{
        backgroundColor: C.surface,
        borderRadius: 28,
        border: `1.5px solid ${C.border}`,
        padding: compact ? 20 : 28,
        display: 'inline-flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 12,
        boxShadow: `0 4px 24px rgba(59,130,246,0.08)`,
        width: 'fit-content',
      }}
    >
      <div
        style={{
          borderRadius: 16,
          overflow: 'hidden',
          border: `1.5px solid ${C.border}`,
        }}
      >
        <QRCodeSVG size={compact ? 140 : 180} />
      </div>
      <div style={{ textAlign: 'center' }}>
        <div
          style={{
            fontFamily: display,
            fontWeight: 700,
            fontSize: compact ? 13 : 14,
            color: C.text,
          }}
        >
          Scan to download
        </div>
        <div
          style={{
            fontFamily: body,
            fontSize: compact ? 11 : 12,
            color: C.muted,
            marginTop: 2,
          }}
        >
          Point your camera at the code
        </div>
      </div>
    </div>
  )
}

// ─── Phone mockups ─────────────────────────────────────────────────────────────
function PhoneMockup({ variant }: { variant: 'route' | 'hours' | 'offline' | 'ai' | 'booking' }) {
  return (
    <div
      style={{
        width: 168,
        height: 300,
        borderRadius: 30,
        border: `5px solid ${C.text}`,
        backgroundColor: C.bg,
        overflow: 'hidden',
        boxShadow: '0 20px 48px rgba(15,23,42,0.18)',
        position: 'relative',
        flexShrink: 0,
      }}
    >
      {/* Status bar */}
      <div
        style={{
          height: 22,
          backgroundColor: C.text,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 10px',
        }}
      >
        <span style={{ color: 'white', fontSize: 8, fontFamily: body, fontWeight: 500 }}>9:41</span>
        <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
          <div style={{ width: 10, height: 5, borderRadius: 1, border: '1px solid white', position: 'relative' }}>
            <div style={{ position: 'absolute', inset: '1px 2px 1px 1px', backgroundColor: 'white', borderRadius: 0 }} />
          </div>
          <div style={{ width: 6, height: 6, borderRadius: '50%', border: '1px solid white' }} />
        </div>
      </div>

      {/* App content */}
      {variant === 'route' && <RouteScreen />}
      {variant === 'hours' && <HoursScreen />}
      {variant === 'offline' && <OfflineScreen />}
      {variant === 'ai' && <AIScreen />}
      {variant === 'booking' && <BookingScreen />}
    </div>
  )
}

function RouteScreen() {
  const stops = [
    { name: 'Eiffel Tower', time: '1.5h', color: C.primary },
    { name: 'Le Marais', time: '1h', color: C.primary },
    { name: 'Louvre', time: '2h', color: C.primary },
  ]
  return (
    <div style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ fontFamily: display, fontWeight: 700, fontSize: 11, color: C.text }}>Today's route</div>
      <div
        style={{
          backgroundColor: C.primarySoft,
          borderRadius: 10,
          padding: '6px 8px',
          fontSize: 9,
          color: C.primaryDark,
          fontFamily: body,
          display: 'flex',
          alignItems: 'center',
          gap: 4,
        }}
      >
        <div style={{ width: 5, height: 5, borderRadius: '50%', backgroundColor: C.primary }} />
        Paris · 3 stops · 4.5 km
      </div>
      {stops.map((s, i) => (
        <div
          key={i}
          style={{
            backgroundColor: C.surface,
            borderRadius: 10,
            padding: '7px 8px',
            display: 'flex',
            alignItems: 'center',
            gap: 6,
            border: `1px solid ${C.border}`,
            position: 'relative',
          }}
        >
          {i < stops.length - 1 && (
            <div
              style={{
                position: 'absolute',
                left: 13,
                top: '100%',
                width: 2,
                height: 6,
                backgroundColor: C.border,
              }}
            />
          )}
          <div
            style={{
              width: 16,
              height: 16,
              borderRadius: '50%',
              backgroundColor: C.primarySoft,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
            }}
          >
            <div style={{ width: 6, height: 6, borderRadius: '50%', backgroundColor: C.primary }} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: display, fontWeight: 600, fontSize: 9, color: C.text }}>{s.name}</div>
          </div>
          <div
            style={{
              fontSize: 8,
              fontFamily: body,
              color: C.muted,
              backgroundColor: C.surfaceMuted,
              padding: '2px 5px',
              borderRadius: 999,
            }}
          >
            {s.time}
          </div>
        </div>
      ))}
      <div
        style={{
          backgroundColor: C.accent,
          borderRadius: 10,
          padding: '8px 0',
          textAlign: 'center',
          fontFamily: display,
          fontWeight: 700,
          fontSize: 10,
          color: 'white',
          marginTop: 2,
        }}
      >
        Start walking
      </div>
    </div>
  )
}

function HoursScreen() {
  const places = [
    { name: "Musée d'Orsay", status: 'Open', close: 'Closes 18:00' },
    { name: 'Centre Pompidou', status: 'Open', close: 'Closes 21:00' },
    { name: 'Palais Royal', status: 'Closed', close: 'Opens 10:00' },
    { name: 'Sainte-Chapelle', status: 'Open', close: 'Closes 17:00' },
  ]
  return (
    <div style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 5 }}>
      <div style={{ fontFamily: display, fontWeight: 700, fontSize: 11, color: C.text }}>Opening hours</div>
      {places.map((p, i) => (
        <div
          key={i}
          style={{
            backgroundColor: C.surface,
            borderRadius: 10,
            padding: '7px 8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            border: `1px solid ${C.border}`,
          }}
        >
          <div>
            <div style={{ fontFamily: display, fontWeight: 600, fontSize: 9, color: C.text }}>{p.name}</div>
            <div style={{ fontFamily: body, fontSize: 8, color: C.muted, marginTop: 1 }}>{p.close}</div>
          </div>
          <div
            style={{
              fontSize: 8,
              fontFamily: body,
              fontWeight: 600,
              color: p.status === 'Open' ? C.success : '#E11D48',
              backgroundColor: p.status === 'Open' ? '#dcfce7' : '#ffe4e6',
              padding: '2px 6px',
              borderRadius: 999,
            }}
          >
            {p.status}
          </div>
        </div>
      ))}
    </div>
  )
}

function OfflineScreen() {
  return (
    <div style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ fontFamily: display, fontWeight: 700, fontSize: 11, color: C.text }}>Saved routes</div>
      {['Paris Weekend', 'Rome Highlights', 'Barcelona Day'].map((name, i) => (
        <div
          key={i}
          style={{
            backgroundColor: C.surface,
            borderRadius: 10,
            padding: '8px',
            border: `1px solid ${C.border}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ fontFamily: display, fontWeight: 600, fontSize: 9, color: C.text }}>{name}</div>
            <div style={{ fontFamily: body, fontSize: 8, color: C.muted, marginTop: 1 }}>Saved · Offline ready</div>
          </div>
          <div
            style={{
              width: 20,
              height: 20,
              borderRadius: '50%',
              backgroundColor: '#dcfce7',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none">
              <path d="M5 13l4 4L19 7" stroke={C.success} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      ))}
      <div
        style={{
          backgroundColor: C.primarySoft,
          borderRadius: 10,
          padding: '7px 8px',
          textAlign: 'center',
          fontFamily: body,
          fontSize: 8,
          color: C.primaryDark,
        }}
      >
        No internet needed once saved
      </div>
    </div>
  )
}

function AIScreen() {
  return (
    <div style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 6, height: '100%' }}>
      <div style={{ fontFamily: display, fontWeight: 700, fontSize: 11, color: C.text }}>AI assistant</div>
      <div
        style={{
          backgroundColor: C.surfaceMuted,
          borderRadius: '12px 12px 12px 4px',
          padding: '7px 8px',
          fontFamily: body,
          fontSize: 8.5,
          color: C.muted,
          lineHeight: 1.4,
        }}
      >
        Hi! Where would you like to explore today?
      </div>
      <div
        style={{
          backgroundColor: C.primary,
          borderRadius: '12px 12px 4px 12px',
          padding: '7px 8px',
          fontFamily: body,
          fontSize: 8.5,
          color: 'white',
          lineHeight: 1.4,
          alignSelf: 'flex-end',
          maxWidth: '80%',
        }}
      >
        Kid-friendly spots near Eiffel Tower open on Sunday?
      </div>
      <div
        style={{
          backgroundColor: C.surfaceMuted,
          borderRadius: '12px 12px 12px 4px',
          padding: '7px 8px',
          fontFamily: body,
          fontSize: 8.5,
          color: C.muted,
          lineHeight: 1.4,
        }}
      >
        Found 5 places nearby — Trocadéro gardens, Champ de Mars, and more.
      </div>
      <div
        style={{
          marginTop: 'auto',
          backgroundColor: C.surface,
          borderRadius: 10,
          border: `1px solid ${C.border}`,
          padding: '6px 8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <span style={{ fontFamily: body, fontSize: 8, color: C.muted }}>Ask anything...</span>
        <div
          style={{
            width: 18,
            height: 18,
            borderRadius: '50%',
            backgroundColor: C.accent,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <svg width="9" height="9" viewBox="0 0 24 24" fill="none">
            <path d="M5 12h14M13 5l7 7-7 7" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
    </div>
  )
}

function BookingScreen() {
  return (
    <div style={{ padding: '10px 8px', display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ fontFamily: display, fontWeight: 700, fontSize: 11, color: C.text }}>Book activities</div>
      {[
        { name: 'Eiffel Tower Summit', price: '€29', tag: 'Skip the line' },
        { name: 'Seine River Cruise', price: '€18', tag: 'Popular' },
        { name: 'Louvre Fast Track', price: '€24', tag: 'Best value' },
      ].map((item, i) => (
        <div
          key={i}
          style={{
            backgroundColor: C.surface,
            borderRadius: 12,
            padding: '8px',
            border: `1px solid ${C.border}`,
          }}
        >
          <div
            style={{
              display: 'inline-block',
              fontSize: 7,
              fontFamily: body,
              fontWeight: 600,
              color: C.accent,
              backgroundColor: C.accentSoft,
              padding: '1px 5px',
              borderRadius: 999,
              marginBottom: 3,
            }}
          >
            {item.tag}
          </div>
          <div style={{ fontFamily: display, fontWeight: 600, fontSize: 9, color: C.text }}>{item.name}</div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginTop: 5,
            }}
          >
            <span style={{ fontFamily: display, fontWeight: 800, fontSize: 11, color: C.text }}>{item.price}</span>
            <div
              style={{
                backgroundColor: C.accent,
                color: 'white',
                borderRadius: 999,
                padding: '3px 10px',
                fontFamily: display,
                fontWeight: 700,
                fontSize: 8,
              }}
            >
              Book
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

// ─── Nav ───────────────────────────────────────────────────────────────────────
function Nav() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <nav
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 clamp(16px, 4vw, 64px)',
        height: 64,
        backgroundColor: scrolled ? 'rgba(247,251,255,0.88)' : 'transparent',
        backdropFilter: scrolled ? 'blur(16px)' : 'none',
        borderBottom: scrolled ? `1px solid ${C.border}` : '1px solid transparent',
        transition: 'background-color 0.3s, border-color 0.3s, backdrop-filter 0.3s',
      }}
    >
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div
          style={{
            width: 32,
            height: 32,
            borderRadius: 10,
            backgroundColor: C.primary,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <MapPinIcon size={18} color="white" />
        </div>
        <span
          style={{
            fontFamily: display,
            fontWeight: 800,
            fontSize: 18,
            color: scrolled ? C.text : 'white',
            letterSpacing: '-0.03em',
            transition: 'color 0.3s',
          }}
        >
          Travel Go
        </span>
      </div>

      {/* Desktop nav links */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 28,
        }}
      >
        {['How it works', 'Features'].map((label) => (
          <a
            key={label}
            href={`#${label.toLowerCase().replace(/\s+/g, '-')}`}
            style={{
              fontFamily: body,
              fontWeight: 500,
              fontSize: 14,
              color: scrolled ? C.muted : 'rgba(255,255,255,0.8)',
              textDecoration: 'none',
              transition: 'color 0.2s',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = scrolled ? C.primaryDark : 'white'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = scrolled ? C.muted : 'rgba(255,255,255,0.8)'
            }}
          >
            {label}
          </a>
        ))}
        <a
          href="#download"
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            padding: '8px 18px',
            backgroundColor: C.accent,
            color: 'white',
            borderRadius: 999,
            textDecoration: 'none',
            fontFamily: display,
            fontWeight: 700,
            fontSize: 13,
            boxShadow: '0 2px 10px rgba(249,115,22,0.24)',
            transition: 'opacity 0.15s',
          }}
          onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.88' }}
          onMouseLeave={(e) => { e.currentTarget.style.opacity = '1' }}
        >
          <PhoneIcon size={14} />
          Download
        </a>
      </div>
    </nav>
  )
}

// ─── Hero ──────────────────────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section
      style={{
        position: 'relative',
        minHeight: '100svh',
        display: 'flex',
        alignItems: 'center',
        backgroundColor: '#1a2a3a',
        overflow: 'hidden',
      }}
    >
      {/* Background image */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage:
            'url(https://images.unsplash.com/photo-1616036902568-fa623d8f0c0a?w=1920&h=1080&fit=crop&auto=format)',
          backgroundSize: 'cover',
          backgroundPosition: 'center 30%',
          opacity: 0.72,
        }}
        aria-hidden
      />
      {/* Gradient overlay — bottom vignette + left fade */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background:
            'linear-gradient(105deg, rgba(15,23,42,0.82) 0%, rgba(15,23,42,0.54) 55%, rgba(15,23,42,0.18) 100%), linear-gradient(to top, rgba(15,23,42,0.65) 0%, transparent 50%)',
        }}
        aria-hidden
      />

      {/* Content */}
      <div
        style={{
          position: 'relative',
          width: '100%',
          maxWidth: 1280,
          margin: '0 auto',
          padding: 'clamp(80px,12vw,140px) clamp(20px,5vw,80px) clamp(60px,8vw,100px)',
        }}
      >
        {/* Eyebrow chip */}
        <div
          style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
            backgroundColor: 'rgba(59,130,246,0.22)',
            border: '1px solid rgba(59,130,246,0.35)',
            borderRadius: 999,
            padding: '5px 14px',
            marginBottom: 24,
            backdropFilter: 'blur(6px)',
          }}
        >
          <div style={{ width: 7, height: 7, borderRadius: '50%', backgroundColor: C.primary }} />
          <span
            style={{
              fontFamily: body,
              fontWeight: 500,
              fontSize: 13,
              color: '#93c5fd',
              letterSpacing: '0.02em',
            }}
          >
            City travel, simplified
          </span>
        </div>

        {/* Wordmark */}
        <div
          style={{
            fontFamily: display,
            fontWeight: 900,
            fontSize: 'clamp(52px, 9vw, 110px)',
            color: 'white',
            letterSpacing: '-0.04em',
            lineHeight: 0.94,
            marginBottom: 'clamp(16px, 2.5vw, 28px)',
          }}
        >
          Travel Go
        </div>

        {/* Headline */}
        <h1
          style={{
            fontFamily: display,
            fontWeight: 700,
            fontSize: 'clamp(22px, 3.8vw, 48px)',
            color: 'rgba(255,255,255,0.92)',
            letterSpacing: '-0.025em',
            lineHeight: 1.2,
            maxWidth: 620,
            margin: '0 0 clamp(14px,2vw,20px)',
          }}
        >
          Plan the perfect city day in minutes.
        </h1>

        {/* Subcopy */}
        <p
          style={{
            fontFamily: body,
            fontSize: 'clamp(15px, 1.8vw, 20px)',
            color: 'rgba(255,255,255,0.72)',
            lineHeight: 1.6,
            maxWidth: 520,
            margin: '0 0 clamp(28px,4vw,44px)',
          }}
        >
          Discover places, build a smart route, and book what matters — from your phone.
        </p>

        {/* CTA group */}
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          <PrimaryButton size="lg">
            <PhoneIcon size={18} />
            Get the app
          </PrimaryButton>
          <SecondaryButton size="lg">
            See how it works
            <ChevronRightIcon size={18} color="white" />
          </SecondaryButton>
        </div>

        {/* Stat strip */}
        <div
          style={{
            display: 'flex',
            gap: 'clamp(20px,4vw,48px)',
            marginTop: 'clamp(36px,5vw,64px)',
            flexWrap: 'wrap',
          }}
        >
          {[
            { val: '200+', label: 'Cities covered' },
            { val: '50k+', label: 'Routes planned' },
            { val: '4.8★', label: 'App rating' },
          ].map((s) => (
            <div key={s.val}>
              <div
                style={{
                  fontFamily: display,
                  fontWeight: 800,
                  fontSize: 'clamp(22px,3vw,32px)',
                  color: 'white',
                  letterSpacing: '-0.03em',
                }}
              >
                {s.val}
              </div>
              <div
                style={{
                  fontFamily: body,
                  fontSize: 13,
                  color: 'rgba(255,255,255,0.55)',
                  marginTop: 2,
                }}
              >
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll hint */}
      <div
        style={{
          position: 'absolute',
          bottom: 28,
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 6,
          opacity: 0.5,
        }}
        aria-hidden
      >
        <div
          style={{
            width: 22,
            height: 36,
            borderRadius: 11,
            border: '2px solid white',
            display: 'flex',
            justifyContent: 'center',
            paddingTop: 6,
          }}
        >
          <div
            style={{
              width: 3,
              height: 8,
              borderRadius: 999,
              backgroundColor: 'white',
              animation: 'scrollBob 1.6s ease-in-out infinite',
            }}
          />
        </div>
      </div>
    </section>
  )
}

// ─── How it works ──────────────────────────────────────────────────────────────
function HowItWorksSection() {
  const steps = [
    {
      n: '01',
      icon: <MapPinIcon size={24} color={C.primary} />,
      title: 'Search a city',
      desc: 'Type a city and instantly see top attractions organized by neighborhood and category.',
    },
    {
      n: '02',
      icon: <RouteIcon size={24} color={C.primary} />,
      title: 'Pick stops & optimize the route',
      desc: "Tap attractions to add them, then let Travel Go build the shortest walking loop that fits your day.",
    },
    {
      n: '03',
      icon: <BookmarkIcon size={24} color={C.primary} />,
      title: 'Walk, save, share — book when ready',
      desc: 'Follow turn-by-turn directions offline, share the route with your group, and book tickets in one tap.',
    },
  ]

  return (
    <section
      id="how-it-works"
      style={{
        backgroundColor: C.surface,
        padding: 'clamp(56px,8vw,96px) clamp(20px,5vw,80px)',
      }}
    >
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: 'clamp(36px,5vw,64px)' }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              backgroundColor: C.primarySoft,
              borderRadius: 999,
              padding: '5px 14px',
              marginBottom: 14,
            }}
          >
            <span style={{ fontFamily: body, fontWeight: 600, fontSize: 13, color: C.primaryDark }}>
              Simple by design
            </span>
          </div>
          <h2
            style={{
              fontFamily: display,
              fontWeight: 800,
              fontSize: 'clamp(28px,4.5vw,52px)',
              color: C.text,
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
              margin: 0,
            }}
          >
            Three steps to your best city day
          </h2>
        </div>

        {/* Steps */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: 20,
          }}
        >
          {steps.map((s, i) => (
            <div
              key={i}
              style={{
                backgroundColor: C.surfaceMuted,
                borderRadius: 24,
                padding: 'clamp(24px,3vw,36px)',
                border: `1.5px solid ${C.border}`,
                display: 'flex',
                flexDirection: 'column',
                gap: 16,
                transition: 'box-shadow 0.2s',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.boxShadow = '0 8px 32px rgba(59,130,246,0.12)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.boxShadow = 'none'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: '50%',
                    backgroundColor: C.primarySoft,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                    border: `1.5px solid ${C.border}`,
                  }}
                >
                  {s.icon}
                </div>
                <span
                  style={{
                    fontFamily: display,
                    fontWeight: 900,
                    fontSize: 13,
                    color: C.primary,
                    letterSpacing: '0.04em',
                  }}
                >
                  {s.n}
                </span>
              </div>
              <div>
                <h3
                  style={{
                    fontFamily: display,
                    fontWeight: 700,
                    fontSize: 'clamp(17px,2vw,22px)',
                    color: C.text,
                    letterSpacing: '-0.02em',
                    margin: '0 0 8px',
                  }}
                >
                  {s.title}
                </h3>
                <p
                  style={{
                    fontFamily: body,
                    fontSize: 15,
                    color: C.muted,
                    lineHeight: 1.6,
                    margin: 0,
                  }}
                >
                  {s.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Features ──────────────────────────────────────────────────────────────────
function FeatureRow({
  icon,
  title,
  body: bodyText,
  detail,
  mockupVariant,
  flip = false,
}: {
  icon: React.ReactNode
  title: string
  body: string
  detail: string[]
  mockupVariant: 'route' | 'hours' | 'offline' | 'ai' | 'booking'
  flip?: boolean
}) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px,1fr))',
        gap: 'clamp(28px,5vw,72px)',
        alignItems: 'center',
        padding: 'clamp(40px,5vw,64px) 0',
        borderTop: `1px solid ${C.border}`,
        direction: flip ? 'rtl' : 'ltr',
      }}
    >
      {/* Text */}
      <div style={{ direction: 'ltr' }}>
        <div
          style={{
            width: 48,
            height: 48,
            borderRadius: 16,
            backgroundColor: C.primarySoft,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            marginBottom: 20,
            border: `1.5px solid ${C.border}`,
          }}
        >
          {icon}
        </div>
        <h3
          style={{
            fontFamily: display,
            fontWeight: 800,
            fontSize: 'clamp(22px,3vw,34px)',
            color: C.text,
            letterSpacing: '-0.03em',
            margin: '0 0 12px',
          }}
        >
          {title}
        </h3>
        <p
          style={{
            fontFamily: body,
            fontSize: 'clamp(15px,1.5vw,17px)',
            color: C.muted,
            lineHeight: 1.65,
            margin: '0 0 20px',
            maxWidth: 480,
          }}
        >
          {bodyText}
        </p>
        <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
          {detail.map((d, i) => (
            <li
              key={i}
              style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: 8,
                fontFamily: body,
                fontSize: 14,
                color: C.muted,
              }}
            >
              <div
                style={{
                  width: 18,
                  height: 18,
                  borderRadius: '50%',
                  backgroundColor: C.primarySoft,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  marginTop: 1,
                }}
              >
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none">
                  <path d="M5 13l4 4L19 7" stroke={C.primary} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
              {d}
            </li>
          ))}
        </ul>
      </div>

      {/* Phone mockup */}
      <div
        style={{
          display: 'flex',
          justifyContent: 'center',
          direction: 'ltr',
        }}
      >
        <div
          style={{
            position: 'relative',
            padding: '16px 20px 20px',
            backgroundColor: C.surfaceMuted,
            borderRadius: 36,
            border: `1.5px solid ${C.border}`,
          }}
        >
          <PhoneMockup variant={mockupVariant} />
          {/* Decorative ring */}
          <div
            style={{
              position: 'absolute',
              inset: -16,
              borderRadius: 48,
              border: `1px solid ${C.border}`,
              pointerEvents: 'none',
            }}
            aria-hidden
          />
        </div>
      </div>
    </div>
  )
}

function FeaturesSection() {
  return (
    <section
      id="features"
      style={{
        backgroundColor: C.bg,
        padding: 'clamp(56px,8vw,96px) clamp(20px,5vw,80px)',
      }}
    >
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        {/* Header */}
        <div style={{ marginBottom: 8 }}>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              backgroundColor: C.primarySoft,
              borderRadius: 999,
              padding: '5px 14px',
              marginBottom: 14,
            }}
          >
            <span style={{ fontFamily: body, fontWeight: 600, fontSize: 13, color: C.primaryDark }}>
              Built for real trips
            </span>
          </div>
          <h2
            style={{
              fontFamily: display,
              fontWeight: 800,
              fontSize: 'clamp(28px,4.5vw,52px)',
              color: C.text,
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
              margin: '0 0 4px',
              maxWidth: 640,
            }}
          >
            Everything you need, nothing you don't.
          </h2>
        </div>

        <FeatureRow
          icon={<RouteIcon size={24} color={C.primary} />}
          title="Smart routes with visit times"
          body="See how long each stop takes and the total walk time before you leave the hotel. Reorder stops with a drag."
          detail={[
            'Estimated visit duration per attraction',
            'Walking time between each stop',
            'Drag-to-reorder and live recalculation',
          ]}
          mockupVariant="route"
        />
        <FeatureRow
          icon={<ClockIcon size={24} color={C.primary} />}
          title="Open now — always accurate"
          body="Real-time opening hours so you never walk to a closed museum on a Tuesday."
          detail={[
            'Live open / closed status on every card',
            "Today's schedule at a glance",
            'Alerts when a place closes in under an hour',
          ]}
          mockupVariant="hours"
          flip
        />
        <FeatureRow
          icon={<DownloadCloudIcon size={24} color={C.primary} />}
          title="Offline — no roaming needed"
          body="Download your full itinerary before you fly. Maps, hours, and directions work without a data connection."
          detail={[
            'One-tap route download before departure',
            'Maps cached for offline navigation',
            'Works in airplane mode or poor signal',
          ]}
          mockupVariant="offline"
        />
        <FeatureRow
          icon={<SparklesIcon size={24} color={C.primary} />}
          title="AI trip assistant"
          body='"Show me kid-friendly places near the Colosseum open on Sunday" — just ask in plain English.'
          detail={[
            'Natural-language trip requests',
            'Filters by distance, category, and hours',
            'Adds results directly to your route',
          ]}
          mockupVariant="ai"
          flip
        />
        <FeatureRow
          icon={<BookmarkIcon size={24} color={C.primary} />}
          title="Partner bookings, in context"
          body="Skip-the-line tickets and hotel deals surfaced right inside your route — no extra app needed."
          detail={[
            'Activity tickets from verified partners',
            'Hotel links for your next stop',
            'Transparent pricing — we label partner links',
          ]}
          mockupVariant="booking"
        />
      </div>
    </section>
  )
}

// ─── Download section ──────────────────────────────────────────────────────────
function DownloadSection() {
  return (
    <section
      id="download"
      style={{
        backgroundColor: C.surfaceMuted,
        padding: 'clamp(56px,8vw,96px) clamp(20px,5vw,80px)',
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: '0 auto',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px,1fr))',
          gap: 'clamp(36px,5vw,64px)',
          alignItems: 'center',
        }}
      >
        {/* Left: text + badges */}
        <div>
          <div
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              backgroundColor: C.primarySoft,
              borderRadius: 999,
              padding: '5px 14px',
              marginBottom: 20,
            }}
          >
            <PhoneIcon size={13} color={C.primaryDark} />
            <span style={{ fontFamily: body, fontWeight: 600, fontSize: 13, color: C.primaryDark }}>
              Available now
            </span>
          </div>

          <h2
            style={{
              fontFamily: display,
              fontWeight: 800,
              fontSize: 'clamp(28px,4vw,48px)',
              color: C.text,
              letterSpacing: '-0.03em',
              lineHeight: 1.1,
              margin: '0 0 14px',
            }}
          >
            Get Travel Go on your phone
          </h2>
          <p
            style={{
              fontFamily: body,
              fontSize: 'clamp(15px,1.5vw,17px)',
              color: C.muted,
              lineHeight: 1.65,
              margin: '0 0 28px',
              maxWidth: 440,
            }}
          >
            Free to download. No account required to explore. Your city, your pace.
          </p>

          <StoreBadgeRow />

          <div
            style={{
              marginTop: 16,
              fontFamily: body,
              fontSize: 13,
              color: C.muted,
              display: 'flex',
              alignItems: 'center',
              gap: 6,
            }}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="9" stroke={C.muted} strokeWidth="1.8" />
              <path d="M12 8v4l2 2" stroke={C.muted} strokeWidth="1.8" strokeLinecap="round" />
            </svg>
            travelgo.app · Free download
          </div>
        </div>

        {/* Right: QR card */}
        <div
          style={{
            display: 'flex',
            justifyContent: 'center',
          }}
        >
          <div
            style={{
              backgroundColor: C.surface,
              borderRadius: 28,
              border: `1.5px solid ${C.border}`,
              padding: 32,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 20,
              boxShadow: '0 8px 40px rgba(59,130,246,0.10)',
              maxWidth: 320,
              width: '100%',
            }}
          >
            {/* QR */}
            <div
              style={{
                borderRadius: 20,
                overflow: 'hidden',
                border: `1.5px solid ${C.border}`,
                padding: 12,
                backgroundColor: 'white',
              }}
            >
              <QRCodeSVG size={200} />
            </div>

            <div style={{ textAlign: 'center' }}>
              <div
                style={{
                  fontFamily: display,
                  fontWeight: 700,
                  fontSize: 16,
                  color: C.text,
                  marginBottom: 4,
                }}
              >
                Scan to download
              </div>
              <div
                style={{
                  fontFamily: body,
                  fontSize: 13,
                  color: C.muted,
                }}
              >
                Point your camera at the code
              </div>
            </div>

            {/* Store hint */}
            <div
              style={{
                display: 'flex',
                gap: 8,
                width: '100%',
              }}
            >
              {[
                { label: 'Google Play', available: true },
                { label: 'App Store', available: false },
              ].map((s) => (
                <div
                  key={s.label}
                  style={{
                    flex: 1,
                    padding: '8px 6px',
                    borderRadius: 12,
                    backgroundColor: s.available ? C.primarySoft : C.surfaceMuted,
                    border: `1px solid ${C.border}`,
                    textAlign: 'center',
                    fontFamily: body,
                    fontSize: 11,
                    color: s.available ? C.primaryDark : C.muted,
                    fontWeight: s.available ? 600 : 400,
                  }}
                >
                  {s.label}
                  {!s.available && (
                    <div style={{ fontSize: 10, color: C.muted, marginTop: 1, opacity: 0.75 }}>Coming soon</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Trust section ─────────────────────────────────────────────────────────────
function TrustSection() {
  return (
    <section
      style={{
        backgroundColor: C.surface,
        padding: '28px clamp(20px,5vw,80px)',
        borderTop: `1px solid ${C.border}`,
        borderBottom: `1px solid ${C.border}`,
      }}
    >
      <p
        style={{
          fontFamily: body,
          fontSize: 14,
          color: C.muted,
          textAlign: 'center',
          margin: 0,
          lineHeight: 1.6,
          maxWidth: 680,
          marginLeft: 'auto',
          marginRight: 'auto',
        }}
      >
        Some links in Travel Go connect to partner hotels and activity providers. We may earn a commission when you book — at no extra cost to you. Partner links are always labeled so you know exactly what you're tapping.
      </p>
    </section>
  )
}

// ─── Final CTA ────────────────────────────────────────────────────────────────
function FinalCTASection() {
  return (
    <section
      style={{
        backgroundColor: C.bg,
        padding: 'clamp(64px,10vw,120px) clamp(20px,5vw,80px)',
        textAlign: 'center',
      }}
    >
      <div style={{ maxWidth: 640, margin: '0 auto' }}>
        <h2
          style={{
            fontFamily: display,
            fontWeight: 900,
            fontSize: 'clamp(34px,6vw,72px)',
            color: C.text,
            letterSpacing: '-0.04em',
            lineHeight: 1.0,
            margin: '0 0 16px',
          }}
        >
          Your next city,{' '}
          <span style={{ color: C.primary }}>sorted.</span>
        </h2>
        <p
          style={{
            fontFamily: body,
            fontSize: 'clamp(15px,1.8vw,18px)',
            color: C.muted,
            lineHeight: 1.6,
            margin: '0 0 32px',
          }}
        >
          Join thousands of travelers who plan smarter, walk further, and miss nothing.
        </p>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 28 }}>
          <PrimaryButton size="lg">
            <PhoneIcon size={18} />
            Download Travel Go
          </PrimaryButton>
        </div>

        {/* Compact QR + badges */}
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: 16,
          }}
        >
          <QrDownloadCard compact />
          <StoreBadgeRow />
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer
      style={{
        backgroundColor: C.bg,
        borderTop: `1px solid ${C.border}`,
        padding: '28px clamp(20px,5vw,80px)',
      }}
    >
      <div
        style={{
          maxWidth: 1280,
          margin: '0 auto',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 16,
        }}
      >
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div
            style={{
              width: 26,
              height: 26,
              borderRadius: 8,
              backgroundColor: C.primary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <MapPinIcon size={14} color="white" />
          </div>
          <span
            style={{
              fontFamily: display,
              fontWeight: 800,
              fontSize: 15,
              color: C.text,
              letterSpacing: '-0.02em',
            }}
          >
            Travel Go
          </span>
        </div>

        {/* Links */}
        <nav style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }} aria-label="Footer links">
          {['Privacy', 'Terms', 'Contact'].map((l) => (
            <a
              key={l}
              href="#"
              style={{
                fontFamily: body,
                fontSize: 13,
                color: C.muted,
                textDecoration: 'none',
                transition: 'color 0.15s',
              }}
              onMouseEnter={(e) => { e.currentTarget.style.color = C.primaryDark }}
              onMouseLeave={(e) => { e.currentTarget.style.color = C.muted }}
            >
              {l}
            </a>
          ))}
        </nav>

        {/* Copyright */}
        <span
          style={{
            fontFamily: body,
            fontSize: 12,
            color: C.muted,
            opacity: 0.7,
          }}
        >
          © {new Date().getFullYear()} Travel Go. All rights reserved.
        </span>
      </div>
    </footer>
  )
}

// ─── Scroll bob animation ─────────────────────────────────────────────────────
const scrollBobStyle = `
@keyframes scrollBob {
  0%, 100% { transform: translateY(0); opacity: 0.8; }
  50% { transform: translateY(5px); opacity: 0.4; }
}
`

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  useFonts()

  return (
    <>
      <style>{scrollBobStyle}</style>
      <div style={{ fontFamily: body, backgroundColor: C.bg }}>
        <Nav />
        <main>
          <HeroSection />
          <HowItWorksSection />
          <FeaturesSection />
          <DownloadSection />
          <TrustSection />
          <FinalCTASection />
        </main>
        <Footer />
      </div>
    </>
  )
}
